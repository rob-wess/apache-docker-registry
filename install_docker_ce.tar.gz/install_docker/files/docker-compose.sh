pathmunge /usr/local/bin/
